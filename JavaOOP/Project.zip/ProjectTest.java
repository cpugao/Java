class ProjectTest {
    public static void main(String[] args) {
        Project project = new Project("Java Project", "Objects and Classes", 20);
        System.out.println(project.elevatorPitch());
    }
}